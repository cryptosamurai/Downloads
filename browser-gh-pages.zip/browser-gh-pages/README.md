## The JSON API Browser

Got a site that implements [JSON API](http://jsonapi.org)? Point this at it, and explore.

### Usage

```bash
$ ./serve.sh
```

Then open a browser at [http://localhost:8000](http://localhost:8000).

Alternatively, you can visit [http://json-api.github.io/browser/](http://json-api.github.io/browser/), hosted on GitHub Pages.
