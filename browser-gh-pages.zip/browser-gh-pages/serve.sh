#!/bin/sh

python -m SimpleHTTPServer
